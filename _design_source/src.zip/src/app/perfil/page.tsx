"use client";

import { useEffect, useState } from "react";

export default function PerfilPage() {
  const [user, setUser] = useState<any>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      setUser(JSON.parse(storedUser));
    }
  }, []);

  if (!user) return <p>No autenticado</p>;

  return (
    <div style={{ padding: "40px" }}>
      <h2>Información Personal</h2>
      <p><strong>Nombre:</strong> {user.nombre}</p>
      <p><strong>Correo:</strong> {user.correo}</p>
      <p><strong>Rol:</strong> {user.rol}</p>
    </div>
  );
}
