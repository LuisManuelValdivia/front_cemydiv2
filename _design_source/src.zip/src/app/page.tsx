import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <>
      {/* HERO FULL WIDTH */}
      <section
        style={{
          position: "relative",
          minHeight: "700px",
          display: "flex",
          alignItems: "center",
          color: "white",
          overflow: "hidden",
        }}
      >
        <Image
          src="/rehabilitacion.webp"
          alt="Rehabilitación"
          fill
          priority
          style={{ objectFit: "cover" }}
        />

        {/* Degradado */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background:
              "linear-gradient(90deg, #134e4a 0%, rgba(30,98,96,0.85) 40%, transparent 100%)",
          }}
        />

        <div
          style={{
            position: "relative",
            zIndex: 10,
            maxWidth: "1200px",
            margin: "0 auto",
            padding: "0 60px",
          }}
        >
          <div style={{ maxWidth: 650 }}>
            <div
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                padding: "6px 14px",
                borderRadius: 999,
                background: "rgba(255,255,255,0.15)",
                marginBottom: 30,
                fontSize: 12,
                fontWeight: 700,
                letterSpacing: 1,
              }}
            >
              ● CALIDAD MÉDICA CERTIFICADA
            </div>

            <h1
              style={{
                fontSize: "4rem",
                fontWeight: 800,
                lineHeight: 1.1,
                marginBottom: 24,
              }}
            >
              Tu bienestar es <br />
              <span style={{ color: "#c8f3ef" }}>
                nuestra prioridad
              </span>
            </h1>

            <p
              style={{
                fontSize: "1.2rem",
                opacity: 0.9,
                marginBottom: 40,
              }}
            >
              Encuentra equipos, ortesis y suministros médicos de alta gama.
              Garantía clara, envíos seguros y asesoría de expertos.
            </p>

            <div style={{ display: "flex", gap: 20 }}>
              <Link
                href="/catalogo"
                style={{
                  background: "white",
                  color: "#134e4a",
                  padding: "16px 32px",
                  borderRadius: 999,
                  fontWeight: 700,
                  textDecoration: "none",
                  boxShadow: "0 10px 25px rgba(0,0,0,0.2)",
                }}
              >
                Explorar catálogo →
              </Link>

              <Link
                href="/register"
                style={{
                  padding: "16px 32px",
                  borderRadius: 999,
                  border: "2px solid rgba(255,255,255,0.6)",
                  color: "white",
                  textDecoration: "none",
                  fontWeight: 600,
                }}
              >
                Crear cuenta
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
