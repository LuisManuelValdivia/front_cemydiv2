"use client";

import Link from "next/link";
import { useAuth } from "@/context/AuthContext";

export default function Header() {
  const { user, logout } = useAuth();

  return (
    <header
      style={{
        background: "linear-gradient(90deg, #1e6260 0%, #2aa09d 100%)",
        padding: "20px 60px",
        display: "grid",
        gridTemplateColumns: "auto 1fr auto",
        alignItems: "center",
        position: "sticky",
        top: 0,
        zIndex: 50,
      }}
    >
      {/* LOGO */}
      <Link
        href="/"
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          fontWeight: 800,
          fontSize: "1.3rem",
          color: "white",
          textDecoration: "none",
        }}
      >
        ✚ CEMyDI
      </Link>

      {/* BUSCADOR */}
      <div style={{ display: "flex", justifyContent: "center" }}>
        <input
          type="search"
          placeholder="Buscar productos..."
          style={{
            width: "100%",
            maxWidth: 500,
            height: 48,
            borderRadius: 999,
            background: "rgba(255,255,255,0.15)",
            border: "1px solid rgba(255,255,255,0.2)",
            color: "white",
            padding: "0 24px",
            outline: "none",
            fontSize: "0.95rem",
          }}
        />
      </div>

      {/* NAV */}
      <nav style={{ display: "flex", alignItems: "center", gap: 20 }}>
        <Link
          href="/catalogo"
          style={{ color: "white", fontWeight: 700, textDecoration: "none" }}
        >
          Catálogo
        </Link>

        {!user ? (
          <>
            <Link
              href="/login"
              style={{
                padding: "10px 22px",
                border: "2px solid white",
                borderRadius: 999,
                color: "white",
                textDecoration: "none",
                fontWeight: 700,
              }}
            >
              Iniciar sesión
            </Link>

            <Link
              href="/register"
              style={{
                padding: "10px 22px",
                background: "white",
                borderRadius: 999,
                color: "#1e6260",
                fontWeight: 800,
                textDecoration: "none",
                boxShadow: "0 4px 12px rgba(0,0,0,0.2)",
              }}
            >
              Crear cuenta
            </Link>
          </>
        ) : (
          <>
            <Link href="/mis-rentas" style={{ color: "white", fontWeight: 700 }}>
              Mis rentas
            </Link>

            <Link href="/mis-compras" style={{ color: "white", fontWeight: 700 }}>
              Mis compras
            </Link>

            <Link href="/perfil" style={{ fontSize: 20 }}>
              👤
            </Link>

            <button
              onClick={logout}
              style={{
                background: "none",
                border: "none",
                color: "#ffdddd",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              Cerrar sesión
            </button>
          </>
        )}
      </nav>
    </header>
  );
}
